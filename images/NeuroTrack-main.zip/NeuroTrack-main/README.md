# NeuroTrack
This is an IOS app that uses the IOS Core Motion and Core Data framework to track the gait and tremor patterns of patients with Parkinson's disease to better understand how their symptoms are progressing. This is used by using the IOS device's pedometer, accelerometer, and gyroscope. This data is then collected and analyzed using data analysis techniques to refine the data.
