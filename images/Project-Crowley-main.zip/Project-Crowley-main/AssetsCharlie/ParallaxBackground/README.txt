Hi! Thank you for downloading my asset pack!

Deafult frame duration 80 miliseconds.

Order of layers:
1. Top layer
2. Light
3. Middle layer
4. Down layer
5. Sky